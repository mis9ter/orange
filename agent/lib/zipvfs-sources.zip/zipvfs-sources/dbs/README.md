== Test Databases

This directory contains copies of a test database compressed using
various compression algorithms and sometimes encrypted.

A simple test of ZIPVFS is to run the "build-shell.sh" script in the 
sibling directory ../src and then cd into this directory and run the
"test.sh" script to verify that there have been no file format changes
that prevent the databases from being understood.
