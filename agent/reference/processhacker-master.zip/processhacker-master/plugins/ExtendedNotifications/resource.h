//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ExtendedNotifications.rc
//
#define IDD_PROCESSES                   101
#define IDC_TEXT_RETURN                 101
#define IDD_SERVICES                    102
#define IDD_LOGGING                     103
#define IDD_GROWL                       104
#define IDC_INCLUDE                     1006
#define IDC_EXCLUDE                     1007
#define IDC_REMOVE                      1008
#define IDC_ADD                         1009
#define IDC_MOVEUP                      1010
#define IDC_MOVEDOWN                    1011
#define IDC_LIST                        1012
#define IDC_TEXT                        1013
#define IDC_EDIT1                       1014
#define IDC_LOGFILENAME                 1014
#define IDC_LICENSE                     1014
#define IDC_BROWSE                      1015
#define IDC_ENABLEGROWL                 1016
#define IDC_INFO                        1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
